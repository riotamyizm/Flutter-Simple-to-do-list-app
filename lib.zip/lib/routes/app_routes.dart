class AppRoutes {
  static const String home = '/';
  static const String addTask = '/add-task';
}
